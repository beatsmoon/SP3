Controls :
WASD - movement
SPACEBAR - jump
R - reload
B - switch shooting mode
1 - switch to primary weapon
2 - switch to secondary weapon
left mouse button - shoot
right mouse button - scope mode
